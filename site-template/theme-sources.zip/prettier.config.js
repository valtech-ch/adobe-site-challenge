module.exports = require('@valtech-ch/eslint-config-base/prettier.config')
