module.exports = { extends: '@valtech-ch/eslint-config-base' }
